﻿	$(function() {
		$('.form-control').datepicker({
            language: 'zh-CN'
        });
	});