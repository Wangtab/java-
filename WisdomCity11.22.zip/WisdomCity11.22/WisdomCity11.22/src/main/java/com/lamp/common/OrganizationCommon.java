package com.lamp.common;

public interface OrganizationCommon {

    /**
     * 截取字符串长度
     */
    int CUT_STRING_LENGTH = 3;
}
