package com.lamp.common;

public class HuaWeiCommon {

    /**
     * accessToken 字段 (电信)
     */
    public static String DX_ACCESS_TOKEN = "accessToken";

    /**
     * 刷新 accessToken 字段 (电信)
     */
    public static String DX_REFRESH_TOKEN = "refreshToken";

    /**
     * accessToken值 (电信)
     */
    public static String DX_ACCESS_TOKEN_VALUE = "";

    /**
     * accessToken 值 (电信)
     */
    public static String DX_REFRESH_TOKEN_VALUE = "";

    /**
     * 项目路径
     */
    public static String PROJECT_PATH = "";


}
