package com.lamp.dao;

import java.util.HashMap;

public interface TSystemOperationMapper {

    int saveLogData(HashMap<String,Object> dataMap);

}
