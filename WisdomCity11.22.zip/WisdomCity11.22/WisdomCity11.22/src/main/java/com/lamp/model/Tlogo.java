package com.lamp.model;

/**
 * Created by lenovo on 2018/1/18.
 */
public class Tlogo {
    private int id;
    private String imager;
    private String name;
    private String uptime;
    private int operid;

    private int orgid;

    public int getOrgid() {
        return orgid;
    }

    public void setOrgid(int orgid) {
        this.orgid = orgid;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getImager() {
        return imager;
    }

    public void setImager(String imager) {
        this.imager = imager;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUptime() {
        return uptime;
    }

    public void setUptime(String uptime) {
        this.uptime = uptime;
    }

    public int getOperid() { return operid; }

    public void setOperid(int operid) {
        this.operid = operid;
    }
}
