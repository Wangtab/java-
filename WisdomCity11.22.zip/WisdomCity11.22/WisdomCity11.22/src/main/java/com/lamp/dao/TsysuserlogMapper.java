package com.lamp.dao;

import com.lamp.model.Tsysuserlog;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface TsysuserlogMapper {
    /*动态增加登录日志*/
    Integer userLogInsert(Tsysuserlog tsysuserlog);
}