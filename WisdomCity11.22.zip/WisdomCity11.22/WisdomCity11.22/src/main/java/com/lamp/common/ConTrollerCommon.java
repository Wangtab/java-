package com.lamp.common;

public interface ConTrollerCommon {

    String DEVICE_CODE = "设备编号";

    String CONTROLLER_TYPE = "控制器类型";

    String CONTROLLER_NUM = "控制器型号";

    String FACTORY_NAME = "厂家名称";

    String CONCENTRATOR_NAME = "所属集中器";

    String BUSINESS = "运营商";

    String PROTOCOL = "协议类型";

    String SIM_CODE = "SIM卡号";
}
