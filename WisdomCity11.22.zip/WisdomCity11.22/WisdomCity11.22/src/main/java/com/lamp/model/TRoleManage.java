package com.lamp.model;

import java.util.Date;

/**
 * 角色类
 */
public class TRoleManage {

    private Integer id;

    private String roleName;

    private String roleDesc;

    private Integer operId;

    private String operTime;

    private Integer createby;

    private String createTime;

    public Integer getId() { return id; }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getRoleDesc() {
        return roleDesc;
    }

    public void setRoleDesc(String roleDesc) {
        this.roleDesc = roleDesc;
    }

    public Integer getOperId() {
        return operId;
    }

    public void setOperId(Integer operId) {
        this.operId = operId;
    }

    public String getOperTime() {
        return operTime;
    }

    public void setOperTime(String operTime) { this.operTime = operTime; }

    public Integer getCreateby() { return createby; }

    public String getCreateTime() { return createTime; }

    public void setCreateby(Integer createby) { this.createby = createby; }

    public void setCreateTime(String createTime) { this.createTime = createTime; }

}
