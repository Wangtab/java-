package com.lamp.model;

public class Trecwarn {
    private Integer id;

    private Integer typeId;

    private String warnValue;

    private String nbDevice;

    private String warnTime;

    private Integer warnId;  //报警ID

    private String ordernum; //维修单号

    private Integer dealFlag; //是否删除

    public String getOrdernum() {
        return ordernum;
    }

    public void setOrdernum(String ordernum) {
        this.ordernum = ordernum;
    }

    public Integer getDealFlag() {
        return dealFlag;
    }

    public void setDealFlag(Integer dealFlag) {
        this.dealFlag = dealFlag;
    }

    public Integer getWarnId() {
        return warnId;
    }

    public void setWarnId(Integer warnId) {
        this.warnId = warnId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getTypeId() {
        return typeId;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    public String getWarnValue() {
        return warnValue;
    }

    public void setWarnValue(String warnValue) {
        this.warnValue = warnValue == null ? null : warnValue.trim();
    }

    public String getNbDevice() {
        return nbDevice;
    }

    public void setNbDevice(String nbDevice) {
        this.nbDevice = nbDevice == null ? null : nbDevice.trim();
    }

    public String getWarnTime() {
        return warnTime;
    }

    public void setWarnTime(String warnTime) {
        this.warnTime = warnTime == null ? null : warnTime.trim();
    }
}