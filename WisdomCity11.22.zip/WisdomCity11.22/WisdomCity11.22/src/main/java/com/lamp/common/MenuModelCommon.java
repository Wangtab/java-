package com.lamp.common;

/**
 * 模块类别
 */
public interface MenuModelCommon {

    /**---------------------- deviceManageModel Start ------------------------*/

    String AREA_MANAGE = "areaManage";//区域管理
    String ROAD_MANAGE = "roadManage";//道路管理
    String ROADLINE_MANAGE = "roadlineManage";//线路配置
    String CENTRALIER_MANAGE = "centralierManage";//集中器配置
    String LAMPKIND_MANAGE = "lampkindManage";//
    String CONTROLLER_MANAGE = "controllerManage";//控制器配置
    String LAMP_MANAGE = "lampManage";//控制器配置
    String DISTRIBUTIONBOX = "distributionbox";//配电箱管理
    String ELEBOX_MANAGE = "eleBoxmanage";//电表管理
    String STANDARD_MANAGE_= "standardManage";//施工标准管理
    String STOCK="Stock";//库存管理
    String INSPECTION_MANAGE="inspectionManage";//巡检管理
    String INFORMATION_MANGAGE="informationManage";//施工信息管理
    String POSITIONMANAGE="positionManage";//位置管理
    String REPAIRPERSOONEL_MANAGE="RepairpersonnelManage";//维修人员管理
    String PLANGROUP_MANAGE="PlanGroupManage";//分组管理
    String GROUPSTRATEMANAGE="GroupstrateManage";//分组策略
    String LAMPSTRATEGYMANAGE="LampstrategyManage";//灯的离线策略
    String LIGHTMODULATIONMANAGE = "LightmodulationManage";//光照调光策略
    /**---------------------- deviceManageModel end ------------------------*/
}
