package com.lamp.service;

import com.lamp.model.Tsysuser;
import com.sun.org.apache.xpath.internal.operations.Bool;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description: Created by MSI on 2017/11/6.
 */
public interface TuserService {

	int addUserLog(Tsysuser tsysuser,String ipAddr); //增加登录日志

    HashMap<String,Object> validedLoginUser(String userName, String pwd);

}
