package com.lamp.service;

public interface TimedTaskService {
    void getNBlOTDevicedata();
    void dealWeatherData();
    void dealAndCalculateData();
    void backupTask();
}
