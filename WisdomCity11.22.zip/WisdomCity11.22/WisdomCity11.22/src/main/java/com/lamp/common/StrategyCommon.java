package com.lamp.common;

public class StrategyCommon {

    /**
     *  灯离线开关
     */
    public static String LAMP_CONTENT_OPEN = "1";
    public static String LAMP_CONTENT_CLOSE = "2";
    public static String LMAP_CONTENT_DIMMING = "3";

    /**
     * 分组策略开关灯 调光
     */
    public static String GROUP_CONTENT_LAMP_SWITCH = "1";
    public static String GROUP_CONTENT_LAMP_DIMMING = "2";

}
