package com.lamp.service;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface TammStatusService {
    Map<String,Object> getammStatusData(HashMap<String,Object> sqlMap);

    ArrayList<ArrayList<String>> ammStateExportExcelList(Integer areaId,Integer roadId,String orgCode);

    Map<String, Object> getPowerPriceData(HashMap<String,Object> sqlMap);
}
