package com.lamp.model;

/**
 * Created by lenovo on 2017/11/27.
 * 施工信息
 */
public class Tbuildinfo {
    private Integer id;
    private Integer roadid;//路段id
    private Integer uid;//员工id
   /* private Integer poleid;//灯杆id*/
    private Integer buildtypeid;//施工标准类型id
    private String buildtime;//施工时间
    private String node;//备注
    private Integer operid;//操作人id
    private String opertime;//操作时间
    private Integer state;//0可用1不可用
    private Integer areaid;
    private String ordernum;
    private Integer repairmanid;
    private String modelnum;
    private String devicenum;
    private Integer repairtype;
    private Integer  deal_result;
    private Integer createby;
    private String createTime;

    public Integer getAreaid() {
        return areaid;
    }

    public void setAreaid(Integer areaid) {
        this.areaid = areaid;
    }

    public String getOrdernum() {
        return ordernum;
    }

    public void setOrdernum(String ordernum) {
        this.ordernum = ordernum;
    }

    public Integer getRepairmanid() {
        return repairmanid;
    }

    public void setRepairmanid(Integer repairmanid) {
        this.repairmanid = repairmanid;
    }

    public String getModelnum() {
        return modelnum;
    }

    public void setModelnum(String modelnum) {
        this.modelnum = modelnum;
    }

    public String getDevicenum() {
        return devicenum;
    }

    public void setDevicenum(String devicenum) {
        this.devicenum = devicenum;
    }

    public Integer getRepairtype() {
        return repairtype;
    }

    public void setRepairtype(Integer repairtype) {
        this.repairtype = repairtype;
    }

    public Integer getDeal_result() {
        return deal_result;
    }

    public void setDeal_result(Integer deal_result) {
        this.deal_result = deal_result;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getRoadid() {
        return roadid;
    }

    public void setRoadid(Integer roadid) {
        this.roadid = roadid;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

   /* public Integer getPoleid() {
        return poleid;
    }

    public void setPoleid(Integer poleid) {
        this.poleid = poleid;
    }*/

    public Integer getBuildtypeid() {
        return buildtypeid;
    }

    public void setBuildtypeid(Integer buildtypeid) {
        this.buildtypeid = buildtypeid;
    }

    public String getBuildtime() {
        return buildtime;
    }

    public void setBuildtime(String buildtime) {
        this.buildtime = buildtime;
    }

    public String getNode() {
        return node;
    }

    public void setNode(String node) {
        this.node = node;
    }

    public Integer getOperid() {
        return operid;
    }

    public void setOperid(Integer operid) {
        this.operid = operid;
    }

    public String getOpertime() {
        return opertime;
    }

    public void setOpertime(String opertime) {
        this.opertime = opertime;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Integer getCreateby() { return createby; }

    public void setCreateby(Integer createby) { this.createby = createby; }

    public String getCreateTime() { return createTime; }

    public void setCreateTime(String createTime) { this.createTime = createTime; }
}
