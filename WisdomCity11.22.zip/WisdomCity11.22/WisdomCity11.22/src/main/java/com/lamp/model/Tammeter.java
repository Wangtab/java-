package com.lamp.model;

public class Tammeter {
    private Integer id;

    private String cAddress;

    private String cName;

    private Integer elecboxId;

    private Integer elecBoxLoop;

    private String cFlag;

    private Integer delFlag;

    private Integer createby;

    private String createTime;

    private Integer operId;

    private String operTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getcAddress() {
        return cAddress;
    }

    public void setcAddress(String cAddress) {
        this.cAddress = cAddress == null ? null : cAddress.trim();
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName == null ? null : cName.trim();
    }

    public Integer getElecboxId() {
        return elecboxId;
    }

    public void setElecboxId(Integer elecboxId) {
        this.elecboxId = elecboxId;
    }

    public Integer getElecBoxLoop() {
        return elecBoxLoop;
    }

    public void setElecBoxLoop(Integer elecBoxLoop) {
        this.elecBoxLoop = elecBoxLoop;
    }

    public String getcFlag() {
        return cFlag;
    }

    public void setcFlag(String cFlag) {
        this.cFlag = cFlag == null ? null : cFlag.trim();
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public Integer getCreateby() {
        return createby;
    }

    public void setCreateby(Integer createby) {
        this.createby = createby;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public Integer getOperId() {
        return operId;
    }

    public void setOperId(Integer operId) {
        this.operId = operId;
    }

    public String getOperTime() {
        return operTime;
    }

    public void setOperTime(String operTime) {
        this.operTime = operTime == null ? null : operTime.trim();
    }
}