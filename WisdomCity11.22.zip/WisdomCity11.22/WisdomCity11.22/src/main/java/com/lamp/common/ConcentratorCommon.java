package com.lamp.common;

public interface ConcentratorCommon {

    String ADDRESS = "集中器地址";

    String TYPE = "集中器类型";

    String NAME = "集中器名称";

    String DES = "集中器描述";

    String AREA_NAME = "所属区域";

    String IP = "IP地址";

    String MASK_CODE = "子网掩码";

    String DEFAULT_GATEWAY = "默认网关";

    String SERVICE_ADDRESS = "连接服务器地址";

    String SERVICE_PORT = "服务器连接端口";

    String LO = "经度";

    String LA = "纬度";

    String USER_NAME = "操作者用户名";

    String ELE_BOX = "配电箱";
}
