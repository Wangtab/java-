package com.lamp.model;

/**
 * Created by lenovo on 2017-11-24.
 *  登陆日志实体类
 *  author:LIULIN
 */
public class Tsysuserlog {
    private String uuid;//新的主键
    private Integer logId;
    private String logDate;
    private String ip;

    private Integer count; //总数
    private Integer userId;

    public String getUuid() {return uuid;}

    public void setUuid(String uuid) {this.uuid = uuid;}

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getLogId() {
        return logId;
    }

    public void setLogId(Integer logId) {
        this.logId = logId;
    }

    public String getLogDate() {
        return logDate;
    }

    public void setLogDate(String logDate) {
        this.logDate = logDate;
    }
}
