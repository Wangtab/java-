package com.lamp.common;

public interface DeviceColumnCommon {

    String AREA_NAME = "区域名称";
    String AREA_DESC = "区域描述";

    String ROAD_NAME = "道路名称";
    String ROAD_DESC = "道路描述";

    String LINE_NAME = "线路名称";

    String LAMP_TYPE = "灯具类型";
    String LAMP_TYPE_DESC = "类型描述";
    String LAMP_TYPE_MODEL = "灯具型号";
    String LAMP_TYPE_POWER = "灯具功率";
    String LAMP_TYPE_FACTORY = "灯具厂家名称";
    String LAMP_TYPE_DIMMING_MODEL = "调光模式";
    String LAMP_TYPE_SUM_POWER = "太阳能板功率";
    String LAMP_TYPE_CEIL_POWER = "蓄电池功率";
    String SUN_LAMP_TYPE_STRING = "太阳能路灯";
    Integer SUN_LAMP_TYPE_INTEGER = 2;//太阳能路灯

    String ELE_BOX_NAME = "配电箱编号";
    String ELE_BOX_LA = "配电箱经度";
    String ELE_BOX_LO = "配电箱纬度";

    String AMMTER_ADDRESS = "电表地址";
    String AMMTER_NAME = "电表名称";
    String AMMTER_ELE_BOX_LOOP = "电表所属配电箱回路";
    String AMMTER_COMMUNICATION = "通信唯一标识";
}
