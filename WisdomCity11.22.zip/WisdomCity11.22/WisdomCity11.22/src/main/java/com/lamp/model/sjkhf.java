package com.lamp.model;

/**
 * Created by lenovo on 2018/1/31.
 */
public class sjkhf {

    private Integer id;
    private String sjkname;
    private String sjkaddress;
    private String info;
    private String addtime;
    private Integer operid;
    private String cztime;
    private Integer delflag;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSjkname() {
        return sjkname;
    }

    public void setSjkname(String sjkname) {
        this.sjkname = sjkname;
    }

    public String getSjkaddress() {
        return sjkaddress;
    }

    public void setSjkaddress(String sjkaddress) {
        this.sjkaddress = sjkaddress;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getAddtime() {
        return addtime;
    }

    public void setAddtime(String addtime) {
        this.addtime = addtime;
    }

    public Integer getOperid() {
        return operid;
    }

    public void setOperid(Integer operid) {
        this.operid = operid;
    }

    public String getCztime() {
        return cztime;
    }

    public void setCztime(String cztime) {
        this.cztime = cztime;
    }

    public Integer getDelflag() {
        return delflag;
    }

    public void setDelflag(Integer delflag) {
        this.delflag = delflag;
    }
}
