package com.lamp.service;

import java.text.ParseException;

public interface IPlatFormTest {
    String initSumPower();

    String initLampByDay() throws ParseException;

    void initRecordPowerData();
}
