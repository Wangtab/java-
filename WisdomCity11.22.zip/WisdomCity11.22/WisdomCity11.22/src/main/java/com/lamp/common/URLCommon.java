package com.lamp.common;

/**
 * Created by lenovo on 2018/2/12.
 */
public class URLCommon {

    public static String WEBINF_URL="E:\\116.62.70.151\\WisdomCity11.22\\WisdomCity11.22\\src\\main\\webapp\\WEB-INF";

    public static String UPLOAD_URL="E:\\116.62.70.151\\WisdomCity11.22\\WisdomCity11.22\\src\\main\\webapp\\upload";
}
