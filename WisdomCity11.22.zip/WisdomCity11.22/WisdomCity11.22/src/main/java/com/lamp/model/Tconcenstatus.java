package com.lamp.model;

import java.math.BigDecimal;

public class Tconcenstatus {
    private Integer id;

    private Integer concenId;

    private Integer linkStatus;

    private BigDecimal aEle;

    private BigDecimal aPov;

    private BigDecimal aPower;

    private BigDecimal bEle;

    private BigDecimal bPov;

    private BigDecimal bPower;

    private BigDecimal cEle;

    private BigDecimal cPov;

    private BigDecimal cPower;

    private BigDecimal temp;

    private String recordTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getConcenId() {
        return concenId;
    }

    public void setConcenId(Integer concenId) {
        this.concenId = concenId;
    }

    public Integer getLinkStatus() {
        return linkStatus;
    }

    public void setLinkStatus(Integer linkStatus) {
        this.linkStatus = linkStatus;
    }

    public BigDecimal getaEle() {
        return aEle;
    }

    public void setaEle(BigDecimal aEle) {
        this.aEle = aEle;
    }

    public BigDecimal getaPov() {
        return aPov;
    }

    public void setaPov(BigDecimal aPov) {
        this.aPov = aPov;
    }

    public BigDecimal getaPower() {
        return aPower;
    }

    public void setaPower(BigDecimal aPower) {
        this.aPower = aPower;
    }

    public BigDecimal getbEle() {
        return bEle;
    }

    public void setbEle(BigDecimal bEle) {
        this.bEle = bEle;
    }

    public BigDecimal getbPov() {
        return bPov;
    }

    public void setbPov(BigDecimal bPov) {
        this.bPov = bPov;
    }

    public BigDecimal getbPower() {
        return bPower;
    }

    public void setbPower(BigDecimal bPower) {
        this.bPower = bPower;
    }

    public BigDecimal getcEle() {
        return cEle;
    }

    public void setcEle(BigDecimal cEle) {
        this.cEle = cEle;
    }

    public BigDecimal getcPov() {
        return cPov;
    }

    public void setcPov(BigDecimal cPov) {
        this.cPov = cPov;
    }

    public BigDecimal getcPower() {
        return cPower;
    }

    public void setcPower(BigDecimal cPower) {
        this.cPower = cPower;
    }

    public BigDecimal getTemp() {
        return temp;
    }

    public void setTemp(BigDecimal temp) {
        this.temp = temp;
    }

    public String getRecordTime() {
        return recordTime;
    }

    public void setRecordTime(String recordTime) {
        this.recordTime = recordTime == null ? null : recordTime.trim();
    }
}