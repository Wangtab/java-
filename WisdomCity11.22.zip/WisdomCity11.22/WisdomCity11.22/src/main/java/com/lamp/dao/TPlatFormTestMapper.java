package com.lamp.dao;

import java.util.List;
import java.util.Map;

/**
 * Created by lenovo on 2017/11/24.
 */

public interface TPlatFormTestMapper {

    int delRecordSumPower();

    List<Map<String, Object>> getFourDaysAgoSumPower();

    Double getSumPowerByDate(String date);

    int batchSaveSumpPowerData(List<Map<String, Object>> list);

    List<Map<String, Object>> getAllRecordData();

    List<Map<String, Object>> getPowerDateByDate(String date);

    int delRecordLampPower();

    int batchSaveLampPower(List<Map<String, Object>> list);

    int clearRecordRoadPower();

    List<Map<String, Object>> getRecordLampPowerDate();

    List<Map<String, Object>> dealRoadRecordPowerByDate(String date);

    int batchSaveRoadPower(List<Map<String, Object>> list);

    int clearRecordAreaPower();

    List<Map<String, Object>> getRecordRoadPowerDate();

    List<Map<String, Object>> dealAreaRecordPowerByDate(String date);

    int batchSaveAreaPower(List<Map<String, Object>> list);
}
