package com.lamp.service;
import java.util.Map;

public interface ScreenService {
    Map<String,Object> getSumPowers(String orgCode);

    Map<String,Object> getAreasPowers(String orgCode);

    Map<String, Object> getSumEnergyData(String orgCode);

    Map<String,Object> getSingleData(String orgCode);
}
