package com.lamp.common;

public interface UserCommon {

    String DEFAULT_PASSWORD = "123456";
}
