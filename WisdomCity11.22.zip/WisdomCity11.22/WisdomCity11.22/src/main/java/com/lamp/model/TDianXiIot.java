package com.lamp.model;

import java.util.Date;

public class TDianXiIot {

    private Integer id;

    private String iotAddress;

    private String appId;

    private String secret;

    private Integer operId;

    private String operTime;

    private String serviceAddress;

    private Integer orgId;    //组织ID

    private Integer iotType;  //iot类型

    private String  accessToken; //授权密钥

    private Date tokenTime; //授权时间


    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public Integer getIotType() {
        return iotType;
    }

    public void setIotType(Integer iotType) {
        this.iotType = iotType;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public Date getTokenTime() {
        return tokenTime;
    }

    public void setTokenTime(Date tokenTime) {
        this.tokenTime = tokenTime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getIotAddress() {
        return iotAddress;
    }

    public void setIotAddress(String iotAddress) {
        this.iotAddress = iotAddress;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public Integer getOperId() {
        return operId;
    }

    public void setOperId(Integer operId) {
        this.operId = operId;
    }

    public String getOperTime() {
        return operTime;
    }

    public void setOperTime(String operTime) {
        this.operTime = operTime;
    }

    public String getServiceAddress() {
        return serviceAddress;
    }

    public void setServiceAddress(String serviceAddress) {
        this.serviceAddress = serviceAddress;
    }
}
