package com.lamp.model;

public class Tcontroller {
    private Integer id;

    private String controllername;

    private String controlleraddr;

    private Integer controllerkindid;

    private Integer concentratorloop;

    private Integer roadid;

    private Double la;

    private Double lo;

    private Integer poleid;

    private Integer operator;

    private String opertime;

    private Integer delflag;

    private Integer concentratorId;

    private Integer controller_factory;

    private String nbCode;

    private String nbDeviceId;

    private String cNum;

    private String factoryName;

    private Integer business;

    private Integer protocol;

    private String simCode;

    private Integer createby;

    private String createTime;

    private Integer NBManageId;

    public Integer getNBManageId() {
        return NBManageId;
    }

    public void setNBManageId(Integer NBManageId) {
        this.NBManageId = NBManageId;
    }

    public String getNbCode() {
        return nbCode;
    }

    public void setNbCode(String nbCode) {
        this.nbCode = nbCode;
    }

    public String getNbDeviceId() {
        return nbDeviceId;
    }

    public void setNbDeviceId(String nbDeviceId) {
        this.nbDeviceId = nbDeviceId;
    }

    public String getcNum() {
        return cNum;
    }

    public void setcNum(String cNum) {
        this.cNum = cNum;
    }

    public String getFactoryName() {
        return factoryName;
    }

    public void setFactoryName(String factoryName) {
        this.factoryName = factoryName;
    }

    public Integer getBusiness() {
        return business;
    }

    public void setBusiness(Integer business) {
        this.business = business;
    }

    public Integer getProtocol() {
        return protocol;
    }

    public void setProtocol(Integer protocol) {
        this.protocol = protocol;
    }

    public String getSimCode() {
        return simCode;
    }

    public void setSimCode(String simCode) {
        this.simCode = simCode;
    }

    public Integer getCreateby() {
        return createby;
    }

    public void setCreateby(Integer createby) {
        this.createby = createby;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public Integer getOperator() {
        return operator;
    }

    public void setOperator(Integer operator) {
        this.operator = operator;
    }

    public Integer getController_factory() {
        return controller_factory;
    }

    public void setController_factory(Integer controller_factory) {
        this.controller_factory = controller_factory;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getControllername() {
        return controllername;
    }

    public void setControllername(String controllername) {
        this.controllername = controllername == null ? null : controllername.trim();
    }

    public String getControlleraddr() {
        return controlleraddr;
    }

    public void setControlleraddr(String controlleraddr) {
        this.controlleraddr = controlleraddr == null ? null : controlleraddr.trim();
    }

    public Integer getControllerkindid() {
        return controllerkindid;
    }

    public void setControllerkindid(Integer controllerkindid) {
        this.controllerkindid = controllerkindid;
    }

    public Integer getConcentratorloop() {
        return concentratorloop;
    }

    public void setConcentratorloop(Integer concentratorloop) {
        this.concentratorloop = concentratorloop;
    }

    public Integer getRoadid() {
        return roadid;
    }

    public void setRoadid(Integer roadid) {
        this.roadid = roadid;
    }

    public Double getLa() {
        return la;
    }

    public void setLa(Double la) {
        this.la = la;
    }

    public Double getLo() {
        return lo;
    }

    public void setLo(Double lo) {
        this.lo = lo;
    }

    public Integer getPoleid() {
        return poleid;
    }

    public void setPoleid(Integer poleid) {
        this.poleid = poleid;
    }

    public String getOpertime() {
        return opertime;
    }

    public void setOpertime(String opertime) {
        this.opertime = opertime == null ? null : opertime.trim();
    }

    public Integer getDelflag() {
        return delflag;
    }

    public void setDelflag(Integer delflag) {
        this.delflag = delflag;
    }

    public Integer getConcentratorId() {
        return concentratorId;
    }

    public void setConcentratorId(Integer concentratorId) {
        this.concentratorId = concentratorId;
    }
}