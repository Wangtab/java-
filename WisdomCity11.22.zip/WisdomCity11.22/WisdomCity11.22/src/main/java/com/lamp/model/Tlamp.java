package com.lamp.model;

import java.math.BigDecimal;

public class Tlamp {
    private Integer id;

    private Integer lampnum;

    private BigDecimal la;

    private BigDecimal lo;

    private Integer operId;

    private String opertime;

    private Integer delflag;

    /*灯具类型名称*/
    private Integer typeId;
    /*控制器*/
    private Integer controllerId;

    private Integer pdId; //配电箱ID

    private Integer dbcircuit; //配电箱回路

    private Integer roadlineId; //主副灯

    private Integer createby; //用户ID

    private String createTime; //登录时间

    private String poleCode; //灯杆编号

    public String getPoleCode() {
        return poleCode;
    }

    public void setPoleCode(String poleCode) {
        this.poleCode = poleCode;
    }

    public Integer getPdId() {
        return pdId;
    }

    public void setPdId(Integer pdId) {
        this.pdId = pdId;
    }

    public Integer getDbcircuit() {
        return dbcircuit;
    }

    public void setDbcircuit(Integer dbcircuit) {
        this.dbcircuit = dbcircuit;
    }

    public Integer getRoadlineId() {
        return roadlineId;
    }

    public void setRoadlineId(Integer roadlineId) {
        this.roadlineId = roadlineId;
    }

    public Integer getCreateby() {
        return createby;
    }

    public void setCreateby(Integer createby) {
        this.createby = createby;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public Integer getControllerId() {
        return controllerId;
    }

    public void setControllerId(Integer controllerId) {
        this.controllerId = controllerId;
    }

    public Integer getTypeId() {
        return typeId;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getLampnum() {
        return lampnum;
    }

    public void setLampnum(Integer lampnum) {
        this.lampnum = lampnum;
    }


    public BigDecimal getLa() {
        return la;
    }

    public void setLa(BigDecimal la) {
        this.la = la;
    }

    public BigDecimal getLo() {
        return lo;
    }

    public void setLo(BigDecimal lo) {
        this.lo = lo;
    }


    public Integer getOperId() {
        return operId;
    }

    public void setOperId(Integer operId) {
        this.operId = operId;
    }

    public String getOpertime() {
        return opertime;
    }

    public void setOpertime(String opertime) {
        this.opertime = opertime == null ? null : opertime.trim();
    }

    public Integer getDelflag() {
        return delflag;
    }

    public void setDelflag(Integer delflag) {
        this.delflag = delflag;
    }
}